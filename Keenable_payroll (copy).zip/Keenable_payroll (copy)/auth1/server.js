const express = require('express');
const { Pool } = require('pg');
const crypto = require('crypto');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3002;

const pool = new Pool({
    user: 'postgres',
    host: 'localhost', 
    database: 'contractor',
    password: 'manish_123',
    port: '5432',
});


app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'views')));
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');



// Serve HTML form
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.post('/addEmployee', async (req, res) => {
    const {
      employeeId, employeeName, employeeSalary, employeeDepartment,
      employeeAadhar, employeePancard, employeeEmail,
      employeeHra, employeeTa, employeeDa, employeeOther,
      employeePfcompany, employeePf, employeeGrosssalary, employeeNetpay,
      employeeGender
    } = req.body;
  
    try {
      // Generate encryption key and IV
      const key = crypto.randomBytes(32);
      const iv = crypto.randomBytes(16);
  
      // Function to encrypt a value
      const encryptValue = (value) => {
        const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
        let encryptedValue = cipher.update(value.toString(), 'utf8', 'hex');
        encryptedValue += cipher.final('hex');
        return encryptedValue;
      };
  
      // Encrypt sensitive fields
      const encryptedSalary = encryptValue(employeeSalary);
      const encryptedHra = encryptValue(employeeHra);
      const encryptedTa = encryptValue(employeeTa);
      const encryptedDa = encryptValue(employeeDa);
      const encryptedOther = encryptValue(employeeOther);
      const encryptedPfcompany = encryptValue(employeePfcompany);
      const encryptedPf = encryptValue(employeePf);
      const encryptedGrosssalary = encryptValue(employeeGrosssalary);
      const encryptedNetpay = encryptValue(employeeNetpay);
  
      // Insert encrypted data into database
      const client = await pool.connect();
      const queryText = `
        INSERT INTO employees (id, name, salary, department, aadhar_card, pan_card, email,
          hra, ta, da, other_allowances, pf_company, pf_employee,
          gross_salary, net_pay, gender, key, iv)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)
      `;
      console.log('Employee Gender:', employeeGender);

      const values = [
        employeeId, employeeName, encryptedSalary, employeeDepartment,
        employeeAadhar, employeePancard, employeeEmail,
        encryptedHra, encryptedTa, encryptedDa,
        encryptedOther, encryptedPfcompany, encryptedPf,
        encryptedGrosssalary, encryptedNetpay,
        employeeGender, key.toString('hex'), iv.toString('hex')
      ];
  
      await client.query(queryText, values);
      client.release();
  
      res.status(201).send('Employee added successfully!');
    } catch (error) {
      console.error('Error adding employee:', error);
      res.status(500).send('Internal Server Error');
    }
  });
  

// Route to fetch list of employees
app.get('/employees', async (req, res) => {
    try {
      const client = await pool.connect();
  
      // Fetch employee data from the database
      const result = await client.query('SELECT id, name, salary, department, aadhar_card, pan_card, email, hra, ta, da, other_allowances, pf_company, pf_employee, gross_salary, net_pay, gender, key, iv FROM employees');
  
      client.release(); // Release the client back to the pool
  
      const employees = result.rows; // Array of employee objects
  
      // Decrypt salary for each employee
      for (let employee of employees) {
        employee.salary = decryptValue(employee.salary, employee.key, employee.iv);
        employee.hra = decryptValue(employee.hra, employee.key, employee.iv);
        employee.ta = decryptValue(employee.ta, employee.key, employee.iv);
        employee.da = decryptValue(employee.da, employee.key, employee.iv);
        employee.other_allowances = decryptValue(employee.other_allowances, employee.key, employee.iv);
        employee.pf_company = decryptValue(employee.pf_company, employee.key, employee.iv);
        employee.pf_employee = decryptValue(employee.pf_employee, employee.key, employee.iv);
        employee.gross_salary = decryptValue(employee.gross_salary, employee.key, employee.iv);
        employee.net_pay = decryptValue(employee.net_pay, employee.key, employee.iv);
      }
  
      // Render the employee list view with decrypted salaries
      res.render('employees-list', { employees });
    } catch (error) {
      console.error('Error fetching employees:', error);
      res.status(500).send('Internal Server Error');
    }
  });
  
  // Function to decrypt a value using key and IV
  function decryptValue(encryptedValue, keyHex, ivHex) {
    try {
      if (!encryptedValue) {
        return 'N/A'; // Return default value if encryptedValue is null or undefined
      }
  
      const key = Buffer.from(keyHex, 'hex');
      const iv = Buffer.from(ivHex, 'hex');
      const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
  
      let decryptedValue = decipher.update(encryptedValue, 'hex', 'utf8');
      decryptedValue += decipher.final('utf8');
  
      return decryptedValue;
    } catch (error) {
      console.error('Error decrypting value:', error);
      return 'N/A'; // Return default value if decryption fails
    }
  }

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
